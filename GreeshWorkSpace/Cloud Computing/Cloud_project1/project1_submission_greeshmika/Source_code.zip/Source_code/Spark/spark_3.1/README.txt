Spark Shell-scala

As I have to execute each command at a tim was not able to attach original source code
but attached queries that i have used in word document file execute each line one by one.

