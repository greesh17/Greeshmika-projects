Spark 3.2 --->used spark shell scala in cloudera

As I have used scala I have to execute each command once so was not to put source code as a whole but instead pasted all commands that I have used while execution in same order with necessary commands 
