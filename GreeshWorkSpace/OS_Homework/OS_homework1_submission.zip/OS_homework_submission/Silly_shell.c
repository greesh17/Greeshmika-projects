#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <termios.h>
#include <ctype.h>

#define LIMIT 256 // max number of tokens for a command
#define MAXLINE 1024 // max number of characters from user input
#define MAX_BUF 1024 // Max no of buffers 
#define MAX_HISTORY 100 // Max no of buffers 
#define TRUE 1
#define FALSE !TRUE
#define MAX_NUM_ARGUMENTS 5     // Mav shell only supports five arguments
#define MAX_COMMAND_SIZE  255    // The maximum command-line size

/* Max jobs limit */
#define MAXJOBS      	16 

/* Job states */
#define UNDEF 0 /* undefined */
#define FG 1    /* running in foreground */
#define BG 2    /* running in background */
#define ST 3    /* stopped */

// Shell pid, pgid, terminal modes
typedef struct _SHELL_PRIV_DATA
{
	struct termios GBSH_TMODES;
	char* current_directory;
	char** environ;
}SHELL_PRIV_DATA;

typedef void handler_t(int);

struct job_t {              /* The job struct */
    pid_t pid;              /* job PID */
    int jid;                /* job ID [1, 2, ...] */
    int state;              /* UNDEF, BG, FG, or ST */
    char cmdline[MAXLINE];  /* command line */
};


static pid_t cmd_pid;
static int no_reprint_prmpt;
char *history[MAX_HISTORY] = {0};	// buffer for history
static int history_counter = 0;
pid_t	execed_pids[15] = {0};
static int exec_counter = 0; 
int nextjid = 1;            /* next job ID to allocate */
struct job_t jobs[MAXJOBS] = {0, 0, 0, {0}}; /* The job list */
int verbose = 0; 	/* If true, will print additional logs */
char shell_prompt[15]; // This string will hold the shell prompt string


/*
 * Function Prototypes 
 */

/* fgpid - Return PID of current foreground job, 0 if no such job */
pid_t fgpid(struct job_t *jobs);
/* clearjob - Clear the entries in a job struct */
void clearjob(struct job_t *job);
/* maxjid - Returns largest allocated job ID */
int maxjid(struct job_t *jobs); 
/* pid2jid - Map process ID to job ID */
int pid2jid(pid_t pid);
/* deletejob - Delete a job whose PID=pid from the job list */
int deletejob(struct job_t *jobs, pid_t pid); 
/* getjobpid  - Find a job (by PID) on the job list */
struct job_t *getjobpid(struct job_t *jobs, pid_t pid);
/* Exit handler */
int handle_exit(char *args[]);
/* Kill handler */
int handle_kill(char *args[]);
/* listjobs - Print the job list */
void listjobs();
/* List jobs */
int list_jobs();
/* handle fg or bg commands */
int handle_fg_bg(char *args[]);
/* getjobjid  - Find a job (by JID) on the job list */
struct job_t *getjobjid(struct job_t *jobs, int jid); 
/* addjob - Add a job to the job list */
int addjob(pid_t pid, int state, char *cmdline); 
/* get pid */
pid_t get_pid_of_jid(int jid);
/* waitfg - Block until process pid is no longer the foreground process */
void waitfg(pid_t pid);

void sigchld_handler(int sig);
void sigint_handler(int sig);
void sigtstp_handler(int sig);
void sigquit_handler(int sig); 
handler_t *Signal(int signum, handler_t *handler);

/**
 * SIGNAL HANDLERS
 */
void sigchld_handler(int sig) 
{
    pid_t pid;
    int status;
    while (1) {
    	pid = waitpid(fgpid(jobs), &status, WUNTRACED|WNOHANG);    //reap zombie children
    	if (pid <= 0)    //No more zombie children to reap
        	break;

        //check if exited normally
    	if(WIFEXITED(status))
            deletejob(jobs, pid);      //delete the child from the job list
        
        //check if child process terminated because of a signal that was not caught
        //SIGINT signal
        else if(WIFSIGNALED(status)){
            printf("Job [%d] (%d) terminated by signal %d\n", pid2jid(pid), pid, WTERMSIG(status));
            deletejob(jobs,pid);        //delete the child from the job list
        }

        //check if child that cause the return is currently stopped
        else if(WIFSTOPPED(status)){
            printf("Job [%d] (%d) stopped by signal %d\n", pid2jid(pid), pid, WSTOPSIG(status));
            struct job_t *job=getjobpid(jobs,pid);
            job->state=ST;      //change job status to ST
        }
    }
    return;
}		

/* 
 * sigint_handler - The kernel sends a SIGINT to the shell whenver the
 *    user types ctrl-c at the keyboard.  Catch it and send it along
 *    to the foreground job.  
 */
void sigint_handler(int sig) 
{
    int pid=fgpid(jobs);

    if(pid>0){
        kill(-pid, SIGINT);      //send SIGINT signal to the entire foreground process group
    }
    return;
}

/*
 * sigtstp_handler - The kernel sends a SIGTSTP to the shell whenever
 *     the user types ctrl-z at the keyboard. Catch it and suspend the
 *     foreground job by sending it a SIGTSTP.  
 */
void sigtstp_handler(int sig) 
{
    int pid=fgpid(jobs);
    
    printf("in sig stop handler\n");
 
    if(pid>0){
        struct job_t *temp;
        temp=getjobpid(jobs, pid);
        temp->state=ST;         //change job status to ST
        kill(-pid,SIGTSTP);     //send SIGTSTP signal to the entire foreground process group
        printf("Job [%d] (%d) stopped by signal %d\n", pid2jid(pid), pid, sig);
    }
    return;
}

/*
 * sigquit_handler - The driver program can gracefully terminate the
 *    child shell by sending it a SIGQUIT signal.
 */
void sigquit_handler(int sig) 
{
    printf("Terminating after receipt of SIGQUIT signal\n");
    exit(1);
}

/*
 * Signal - wrapper for the sigaction function
 */
handler_t *Signal(int signum, handler_t *handler) 
{
    struct sigaction action, old_action;

    action.sa_handler = handler;  
    sigemptyset(&action.sa_mask); /* block sigs of type being handled */
    action.sa_flags = SA_RESTART; /* restart syscalls if possible */

    if (sigaction(signum, &action, &old_action) < 0)
	perror("Signal error");
    return (old_action.sa_handler);
}



/* fgpid - Return PID of current foreground job, 0 if no such job */
pid_t fgpid(struct job_t *jobs) 
{
    int i;

    for (i = 0; i < MAXJOBS; i++)
	if (jobs[i].state == FG)
	    return jobs[i].pid;
    return 0;
}

/* 
 * waitfg - Block until process pid is no longer the foreground process
 */
void waitfg(pid_t pid)
{
    /*while(pid == fgpid(jobs)) {
        sleep(1);
    }*/
    struct job_t *jobtowait;
    jobtowait=getjobpid(jobs,pid);
    while(jobtowait->state==FG)     //if job state is FG waiting for that job
        sleep(1);
    return;
}

/*
 * numbers_only - to check there are only numbers in string
 */

int numbers_only(const char *s)
{
    while (*s) {
        if (isdigit(*s++) == 0) return 0;
    }

    return 1;
}

/* clearjob - Clear the entries in a job struct */
void clearjob(struct job_t *job) 
{
    job->pid = 0;
    job->jid = 0;
    job->state = UNDEF;
    job->cmdline[0] = '\0';
}

/* addjob - Add a job to the job list */
int addjob(pid_t pid, int state, char *cmdline) 
{
    int i;
    
    if (pid < 1)
	return 0;

    for (i = 0; i < MAXJOBS; i++) {
	if (jobs[i].pid == 0) {
	    jobs[i].pid = pid;
	    jobs[i].state = state;
	    jobs[i].jid = nextjid++;
	    if (nextjid > MAXJOBS)
		nextjid = 1;
	    strcpy(jobs[i].cmdline, cmdline);
  	    if(verbose){
	        printf("Added job [%d] %d %s\n", jobs[i].jid, jobs[i].pid, jobs[i].cmdline);
            }
            return 1;
	}
    }
    printf("Tried to create too many jobs\n");
    return 0;
}

/* maxjid - Returns largest allocated job ID */
int maxjid(struct job_t *jobs) 
{
    int i, max=0;

    for (i = 0; i < MAXJOBS; i++)
	if (jobs[i].jid > max)
	    max = jobs[i].jid;
    return max;
}

/* pid2jid - Map process ID to job ID */
int pid2jid(pid_t pid) 
{
    int i;

    if (pid < 1)
	return 0;
    for (i = 0; i < MAXJOBS; i++)
	if (jobs[i].pid == pid) {
            return jobs[i].jid;
        }
    return 0;
}

/* deletejob - Delete a job whose PID=pid from the job list */
int deletejob(struct job_t *jobs, pid_t pid) 
{
    int i;

    if (pid < 1)
	return 0;

    for (i = 0; i < MAXJOBS; i++) {
	if (jobs[i].pid == pid) {
	    clearjob(&jobs[i]);
	    nextjid = maxjid(jobs)+1;
	    return 1;
	}
    }
    return 0;
}

/* getjobpid  - Find a job (by PID) on the job list */
struct job_t *getjobpid(struct job_t *jobs, pid_t pid)
{
    int i;

    if (pid < 1)
	return NULL;
    for (i = 0; i < MAXJOBS; i++)
	if (jobs[i].pid == pid)
	    return &jobs[i];
    return NULL;
}

/* getjobjid  - Find a job (by JID) on the job list */
struct job_t *getjobjid(struct job_t *jobs, int jid) 
{
    int i;

    if (jid < 1)
	return NULL;
    for (i = 0; i < MAXJOBS; i++)
	if (jobs[i].jid == jid)
	    return &jobs[i];
    return NULL;
}

/* listjobs - Print the job list */
void listjobs() 
{
    int i;
    
    for (i = 0; i < MAXJOBS; i++) {
	if (jobs[i].pid != 0) {
	    printf("[%d] (%d) ", jobs[i].jid, jobs[i].pid);
	    switch (jobs[i].state) {
		case BG: 
		    printf("Running ");
		    break;
		case FG: 
		    printf("Foreground ");
		    break;
		case ST: 
		    printf("Stopped ");
		    break;
	    default:
		    printf("listjobs: Internal error: job[%d].state=%d ", 
			   i, jobs[i].state);
	    }
	    printf("%s\n", jobs[i].cmdline);
	}
    }
}

/* 
 * do_bgfg - Execute the builtin bg and fg commands
 */
void do_bgfg(char **argv)
{
    int pid,jid;
    struct job_t *job;

    if(argv[1]==NULL){          //to checks if it has second argument
	   printf("%s command requires PID or %%jobid argument\n", argv[0]);
	   return;
    }

    else if(argv[1][0]=='%'){   //to check if second argument is valid(in case of jid)
	   char temp1,temp2[10];
	   sscanf(argv[1], "%c %s",&temp1,temp2);
	   if(!numbers_only(temp2)){
            printf("%s: argument must be a PID or %%jobid\n", argv[0]);
		    return;
	   }
    }

    else if(!numbers_only(argv[1])){    //to check if second argument is valid(in case of pid)
	printf("%s: argument must be a PID or %%jobid\n", argv[0]);
	return;
    }

    {
	if(numbers_only(argv[1])){
        pid=atoi(argv[1]);
		if((job=getjobpid(jobs, pid))==NULL){     //get PID and check if it is in job table
			printf("(%d): No such process\n",atoi(argv[1]));
			return;
		}
	}
	else{
		char first,rest[10];
		sscanf(argv[1], "%c %s",&first,rest);
        jid=atoi(rest);
		if((job=getjobjid(jobs,jid))==NULL){      //get JID and check if it is in job table
			printf("%s (%s): No such job\n",argv[0],argv[1]);
			return;
		}
	}

    }
    if(!strcmp(argv[0],"bg") && job->state==ST){
        printf("[%d] (%d) %s\n", job->jid, job->pid, job->cmdline);
        job->state = BG;            //change state FG-or-ST to BG
        kill(-(job->pid), SIGCONT); //send signal SIGCONT to whole group of given job
    }
    else if(!strcmp(argv[0],"fg")){
        if(job->state==ST){
            job->state = FG;        //change state ST to FG
            kill(-(job->pid), SIGCONT); //send signal SIGCONT to whole group of given job
        }
        else if(job->state==BG)     //change state BG to FG
            job->state = FG;        
        waitfg(job->pid);           //wait for fg to finish
    }

    return;
}

/* get pid */
pid_t get_pid_of_jid(int jid)
{
	int i;
	printf("jid = %d\n", jid);

	for (i = 0; i < MAXJOBS; i++) {
		printf("jobs[%d].jid = %d\n", i, jobs[i].pid);
		if (jobs[i].jid == jid) {
			return jobs[i].pid; 
		}
	}
	return -1;	
}


/* Exit handler */
int handle_exit(char *args[])
{
	struct job_t *job = jobs;
        int i = 0;
      	printf("Exiting... \n");
	for(i = 0; i < MAXJOBS; i++) {
            if((job[i].state == ST) || (jobs[i].state == BG)) {
                printf("You can't exit, there are still stopped jobs in job-table\n");
                return 1;
            }
        }
        exit(0);
}

/* Kill handler */
int handle_kill(char *args[])
{
	pid_t pid;
   	if ((pid = get_pid_of_jid(atoi(args[1]))) != -1) {
		printf("sending kill signal to %d\n", pid);
       	 	kill(pid, SIGKILL); //send signal SIGINT to whole group of given job
		deletejob(jobs, pid);	
	}
	return 1;
}

/* List jobs */
int list_jobs()
{
	listjobs(jobs);
	return 1;
}

/* handle fg or bg commands */
int handle_fg_bg(char *args[])
{
	do_bgfg(args);	
	return 1;
}


/**
 * Function used to initialize our shell. We used the approach explained in
 */
void init_shell(SHELL_PRIV_DATA *p_shell_priv_data)
{
	pid_t term_pid;
	pid_t term_gid;
	int   is_term;
	// See if we are running interactively
	term_pid = getpid();
        // The shell is interactive if STDIN is the terminal  
        is_term = isatty(STDIN_FILENO);  

		if (is_term) {
			// Loop until we are in the foreground
			while (tcgetpgrp(STDIN_FILENO) != (term_gid = getpgrp()))
					kill(term_pid, SIGTTIN);             

			    /* Install the signal handlers */
    			Signal(SIGINT,  sigint_handler);   /* ctrl-c */
	  	        Signal(SIGTSTP, sigtstp_handler);  /* ctrl-z */
		        Signal(SIGCHLD, sigchld_handler);  /* Terminated or stopped child */
    			/* This one provides a clean way to kill the shell */
		        Signal(SIGQUIT, sigquit_handler); 

			// Put ourselves in our own process group
			setpgid(term_pid, term_pid); // we make the shell process the new process group leader
			term_gid = getpgrp();
			if (term_pid != term_gid) {
					printf("Error, the shell is not process group leader");
					exit(EXIT_FAILURE);
			}
			// Grab control of the terminal
			tcsetpgrp(STDIN_FILENO, term_gid);  
			// Save default terminal attributes for shell
			tcgetattr(STDIN_FILENO, &p_shell_priv_data->GBSH_TMODES);
			// Get the current directory that will be used in different methods
			p_shell_priv_data->current_directory = (char*) calloc(1024, sizeof(char));
        } else {
                printf("Could not make the shell interactive.\n");
                exit(EXIT_FAILURE);
        }
}

/**
 * Method to change directory
 */
int change_directory(char* args[])
{
	// If we write no path (only 'cd'), then go to the home directory
	if (args[1] == NULL) {
		chdir(getenv("HOME")); 
		return 1;
	}
	// Else we change the directory to the one specified by the 
	// argument, if possible
	else{ 
		if (chdir(args[1]) == -1) {
			printf(" %s: no such directory\n", args[1]);
            		return -1;
		}
	}
	return 0;
}

/**
 * Method used to manage the environment variables with different
 * options
 */ 
int manage_environ(char * args[], int option, SHELL_PRIV_DATA *p_shell_priv_data)
{
	char **env_aux;
	switch(option) 
	{
		// Case 'environ': we print the environment variables along with
		// their values
		case 0: 
			for(env_aux = p_shell_priv_data->environ; *env_aux != 0; env_aux ++){
				printf("%s\n", *env_aux);
			}
			break;
		// Case 'setenv': we set an environment variable to a value
		case 1: 
			if((args[1] == NULL) && args[2] == NULL){
				printf("%s","Not enought input arguments\n");
				return -1;
			}
			
			// We use different output for new and overwritten variables
			if(getenv(args[1]) != NULL){
				printf("%s", "The variable has been overwritten\n");
			}else{
				printf("%s", "The variable has been created\n");
			}
			
			// If we specify no value for the variable, we set it to ""
			if (args[2] == NULL){
				setenv(args[1], "", 1);
			// We set the variable to the given value
			}else{
				setenv(args[1], args[2], 1);
			}
			break;
		// Case 'unsetenv': we delete an environment variable
		case 2:
			if(args[1] == NULL){
				printf("%s","Not enought input arguments\n");
				return -1;
			}
			if(getenv(args[1]) != NULL){
				unsetenv(args[1]);
				printf("%s", "The variable has been erased\n");
			}else{
				printf("%s", "The variable does not exist\n");
			}
		break;
			
			
	}
	return 0;
}
 
/**
* Method for launching a program. It can be run in the background
* or in the foreground
*/ 
void launch_prog(char **args, int background, SHELL_PRIV_DATA *p_shell_priv_data)
{	 
	int err = -1;
	sigset_t set;

        sigemptyset(&set);                      //initialize signal set
        sigaddset(&set, SIGCHLD);               //add SIGCHLD to the set
        sigprocmask(SIG_BLOCK, &set, NULL);     //block the signal
	 
	 if ((cmd_pid = fork()) == -1) {
		 printf("Child process could not be created\n");
		 return;
	 }
	 // cmd_pid == 0 implies the following code is related to the child process
	if(cmd_pid == 0) {
		// We set the child to ignore SIGINT signals (we want the parent
		// process to handle them with signal_handler_int)	
		//signal(SIGINT, SIG_IGN);
	        sigprocmask(SIG_UNBLOCK, &set, NULL);   //unblock signal SIGCHILD
                setpgrp();  //making the calling process as a process group leader i.e. making child a group leader		

		setenv("parent",getcwd(p_shell_priv_data->current_directory, 1024),1);	
	
		// If we launch non-existing commands we end the process
		if (execvp(args[0], args) == err) {
			printf("Command not found\n");
			perror(args[0]);
			kill(getpid(), SIGTERM);
		}
	 } else {
		 if (background)		
			addjob(cmd_pid, BG, args[0]);
			//addjob(jobs, cmd_pid, BG, args[0]);
	  	 else
			addjob(cmd_pid, FG, args[0]); 
			//addjob(jobs, cmd_pid, FG, args[0]); 
	
		 sigprocmask(SIG_UNBLOCK, &set, NULL);   //unblock signal SIGCHILD
		 // The following will be executed by the parent
		 
		 // If the process is not requested to be in background, we wait for
		 // the child to finish.
		 if (exec_counter < 15)
			 execed_pids[exec_counter++] = cmd_pid;
		 else {
			exec_counter = 0;
			execed_pids[exec_counter++] = cmd_pid;
		 }

		 if (background == 0){
			// waitpid(cmd_pid, NULL, 0);
			waitfg(cmd_pid);
		 }else{
			 // In order to create a background process, the current process
			 // should just skip the call to wait. The SIGCHILD handler
			 // signal_handler_child will take care of the returning values
			 // of the childs.
			 //printf("Process created with PID: %d\n",cmd_pid);
			 printf("[%d] (%d) %s\n", pid2jid(cmd_pid), cmd_pid, args[0]);     //print background job info	
		 }	 
	}
}
 
/**
* Method used to manage I/O redirection
*/ 
void fileIO(char * args[], char* inputFile, char* outputFile, int option, SHELL_PRIV_DATA *p_shell_priv_data)
{
	 
	int err = -1;
	int file_descriptor; // between 0 and 19, describing the output or input file
	
	if ((cmd_pid = fork()) == -1) {
		printf("Child process could not be created\n");
		return;
	}
	if (cmd_pid==0) {
		// Option 0: output redirection
		if (option == 0) {
			// We open (create) the file truncating it at 0, for write only
			file_descriptor = open(outputFile, O_CREAT | O_TRUNC | O_WRONLY, 0600); 
			// We replace de standard output with the appropriate file
			dup2(file_descriptor, STDOUT_FILENO); 
			close(file_descriptor);
		// Option 1: input and output redirection
		}else if (option == 1){
			// We open file for read only (it's STDIN)
			file_descriptor = open(inputFile, O_RDONLY, 0600);  
			// We replace de standard input with the appropriate file
			dup2(file_descriptor, STDIN_FILENO);
			close(file_descriptor);
			// Same as before for the output file
			file_descriptor = open(outputFile, O_CREAT | O_TRUNC | O_WRONLY, 0600);
			dup2(file_descriptor, STDOUT_FILENO);
			close(file_descriptor);		 
		}
		 
		setenv("parent",getcwd(p_shell_priv_data->current_directory, 1024),1);
		
		if (execvp(args[0], args) == err) {
			printf("err");
			kill(getpid(),SIGTERM);
		}		 
	}
	waitpid(cmd_pid,NULL,0);
}

/**
* Method used to manage pipes.
*/ 
void pipe_handler(char *args[])
{
	// File descriptors
	int filedes[2]; // pos. 0 output, pos. 1 input of the pipe
	int filedes2[2];
	char *command[256];
	pid_t pid;
	int err = -1, end = 0, num_cmds = 0;
	// Variables used for the different loops
	int i = 0, j = 0, k = 0, l = 0;
	
	// First we calculate the number of commands (they are separated
	// by '|')
	while (args[l] != NULL){
		if (strcmp(args[l],"|") == 0){
			num_cmds++;
		}
		l++;
	}
	num_cmds++;
	
	// Main loop of this method. For each command between '|', the
	// pipes will be configured and standard input and/or output will
	// be replaced. Then it will be executed
	while (args[j] != NULL && end != 1){
		k = 0;
		// We use an auxiliary array of pointers to store the command
		// that will be executed on each iteration
		while (strcmp(args[j],"|") != 0){
			command[k] = args[j];
			j++;	
			if (args[j] == NULL){
				// 'end' variable used to keep the program from entering
				// again in the loop when no more arguments are found
				end = 1;
				k++;
				break;
			}
			k++;
		}
		// Last position of the command will be NULL to indicate that
		// it is its end when we pass it to the exec function
		command[k] = NULL;
		j++;		
		
		// Depending on whether we are in an iteration or another, we
		// will set different descriptors for the pipes inputs and
		// output. This way, a pipe will be shared between each two
		// iterations, enabling us to connect the inputs and outputs of
		// the two different commands.
		if (i % 2 != 0){
			pipe(filedes); // for odd i
		}else{
			pipe(filedes2); // for even i
		}
		
		pid=fork();
		
		if(pid==-1){			
			if (i != num_cmds - 1){
				if (i % 2 != 0){
					close(filedes[1]); // for odd i
				}else{
					close(filedes2[1]); // for even i
				} 
			}			
			printf("Child process could not be created\n");
			return;
		}
		if(pid==0){
			// If we are in the first command
			if (i == 0){
				dup2(filedes2[1], STDOUT_FILENO);
			}
			// If we are in the last command, depending on whether it
			// is placed in an odd or even position, we will replace
			// the standard input for one pipe or another. The standard
			// output will be untouched because we want to see the 
			// output in the terminal
			else if (i == num_cmds - 1){
				if (num_cmds % 2 != 0){ // for odd number of commands
					dup2(filedes[0],STDIN_FILENO);
				}else{ // for even number of commands
					dup2(filedes2[0],STDIN_FILENO);
				}
			// If we are in a command that is in the middle, we will
			// have to use two pipes, one for input and another for
			// output. The position is also important in order to choose
			// which file descriptor corresponds to each input/output
			}else{ // for odd i
				if (i % 2 != 0){
					dup2(filedes2[0],STDIN_FILENO); 
					dup2(filedes[1],STDOUT_FILENO);
				}else{ // for even i
					dup2(filedes[0],STDIN_FILENO); 
					dup2(filedes2[1],STDOUT_FILENO);					
				} 
			}
			
			if (execvp(command[0],command)==err){
				kill(getpid(),SIGTERM);
			}		
		}
				
		// CLOSING DESCRIPTORS ON PARENT
		if (i == 0){
			close(filedes2[1]);
		}
		else if (i == num_cmds - 1){
			if (num_cmds % 2 != 0){					
				close(filedes[0]);
			}else{					
				close(filedes2[0]);
			}
		}else{
			if (i % 2 != 0){					
				close(filedes2[0]);
				close(filedes[1]);
			}else{					
				close(filedes[0]);
				close(filedes2[1]);
			}
		}
		waitpid(pid,NULL,0);
		i++;	
	}
}
			
/**
* Method used to handle the commands entered via the standard input
*/ 
int command_handler(char *args[], SHELL_PRIV_DATA *p_shell_priv_data)
{
	int i = 0;
	int j = 0, k = 1;
	int fileDescriptor;
	int standardOut;
	int aux;
	int background = 0;
	char *args_aux[256] = {0};
	
	// We look for the special characters and separate the command itself
	// in a new array for the arguments
	while ( args[j] != NULL){
		if ( (strcmp(args[j],">") == 0) || (strcmp(args[j],"<") == 0) || (strcmp(args[j],"&") == 0)){
			break;
		}
		args_aux[j] = args[j];
		j++;
	}
	if (args[0][0] == '!') {
		char *ptr = &args[0][1];
		int index;

		index = atoi(ptr);
		if (history[index] != NULL) {
			int len = strlen(history[index]);
			args_aux[0] = history[index];
			args_aux[0][len - 1] = '\0';

			launch_prog(args_aux, 0, p_shell_priv_data);
			return 1;
		} else {
			return -1;
		}
	}

	if (strcmp(args[0], "newprompt") == 0) {
		memset(shell_prompt, 0, 15);

		if (args[1] != NULL) {
			memcpy(shell_prompt, args[1], strlen(args[1]));
		} else {
			memcpy(shell_prompt, "SillyShell", strlen("SillyShell"));	
		}
		return 1;
	}

	if (strcmp(args[0], "kill") == 0) {
		handle_kill(args);	
		return 1;
	}

	if (strcmp(args[0],"setpath") == 0){
		char *path = NULL;
		int len = 0;
		while (args[k] != NULL){
			path = getenv("PATH");
			k++;		
		}
		return 1;
	}
	else if (strcmp(args[0], "jobs") == 0) {
		list_jobs();
		return 1;
	}
	else if ((strcmp(args[0], "fg") == 0) || (strcmp(args[0], "bg") == 0)) {
		handle_fg_bg(args);
		return 1;
	} 
	// 'exit' command quits the shell
	else if(strcmp(args[0],"exit") == 0) exit(0);
	// 'pwd' command prints the current directory
	else if(strcmp(args[0],"listpids") == 0) {
		int pos = exec_counter;
		if ((pos < 15) && (execed_pids[pos + 1] != 0))
		{
			int i = pos+1;
			while (i < 15) {
				printf("%d: %d\n", i, execed_pids[i]);	
				i++; 
			} 
			if (i == 15) {
				i = 0;
				while (i < exec_counter) { 
					printf("%d: %d\n", i, execed_pids[i]);	
					i++; 
				}
			}
		} else {
			int i = 0;
			while (i < exec_counter) {
				printf("%d: %d\n", i, execed_pids[i]);	
				i++;
			}	
		}
		
	}
 	else if (strcmp(args[0],"pwd") == 0){
		if (args[j] != NULL){
			// If we want file output
			if ( (strcmp(args[j],">") == 0) && (args[j+1] != NULL) ){
				fileDescriptor = open(args[j+1], O_CREAT | O_TRUNC | O_WRONLY, 0600); 
				// We replace de standard output with the appropriate file
				standardOut = dup(STDOUT_FILENO); 	// first we make a copy of stdout
													// because we'll want it back
				dup2(fileDescriptor, STDOUT_FILENO); 
				close(fileDescriptor);
				printf("%s\n", getcwd(p_shell_priv_data->current_directory, 1024));
				dup2(standardOut, STDOUT_FILENO);
			}
		}else{
			printf("%s\n", getcwd(p_shell_priv_data->current_directory, 1024));
		}
	} 
 	// 'clear' command clears the screen
	else if (strcmp(args[0],"clear") == 0) system("clear");
	// 'cd' command to change directory
	else if (strcmp(args[0],"cd") == 0) change_directory(args);
	else if (strcmp(args[0], "$PATH") == 0)
			printf("%s\n", getenv("PATH"));
	else if ((strcmp(args[0], "echo") == 0) && (strcmp(args[1], "$PATH") == 0))
			printf("%s\n", getenv("PATH"));
	// 'environ' command to list the environment variables
	else if (strcmp(args[0],"environ") == 0) {
		if (args[j] != NULL){
			// If we want file output
			if ( (strcmp(args[j],">") == 0) && (args[j+1] != NULL) ){
				fileDescriptor = open(args[j+1], O_CREAT | O_TRUNC | O_WRONLY, 0600); 
				// We replace de standard output with the appropriate file
				standardOut = dup(STDOUT_FILENO); 	// first we make a copy of stdout
													// because we'll want it back
				dup2(fileDescriptor, STDOUT_FILENO); 
				close(fileDescriptor);
				manage_environ(args, 0, p_shell_priv_data);
				dup2(standardOut, STDOUT_FILENO);
			}
		}else{
			manage_environ(args,0, p_shell_priv_data);
		}
	}
	// 'setenv' command to set environment variables
	else if (strcmp(args[0],"setenv") == 0) manage_environ(args,1, p_shell_priv_data);
	// 'unsetenv' command to undefine environment variables
	else if (strcmp(args[0],"unsetenv") == 0) manage_environ(args,2, p_shell_priv_data);
	else{
		// If none of the preceding commands were used, we invoke the
		// specified program. We have to detect if I/O redirection,
		// piped execution or background execution were solicited
		while (args[i] != NULL && background == 0){
			// If background execution was solicited (last argument '&')
			// we exit the loop
			if (strcmp(args[i],"&") == 0){
				background = 1;
			// If '|' is detected, piping was solicited, and we call
			// the appropriate method that will handle the different
			// executions
			}else if (strcmp(args[i],"|") == 0){
				pipe_handler(args);
				return 1;
			// If '<' is detected, we have Input and Output redirection.
			// First we check if the structure given is the correct one,
			// and if that is the case we call the appropriate method
			}else if (strcmp(args[i],"<") == 0){
				aux = i+1;
				if (args[aux] == NULL || args[aux+1] == NULL || args[aux+2] == NULL ){
					printf("Not enough input arguments\n");
					return -1;
				}else{
					if (strcmp(args[aux+1],">") != 0){
						printf("Usage: Expected '>' and found %s\n",args[aux+1]);
						return -2;
					}
				}
				fileIO(args_aux, args[i+1], args[i+3], 1, p_shell_priv_data);
				return 1;
			}
			// If '>' is detected, we have output redirection.
			// First we check if the structure given is the correct one,
			// and if that is the case we call the appropriate method
			else if (strcmp(args[i],">") == 0){
				if (args[i+1] == NULL){
					printf("Not enough input arguments\n");
					return -1;
				}
				fileIO(args_aux, NULL, args[i+1], 0, p_shell_priv_data);
				return 1;
			}
			i++;
		}
		// We launch the program with our method, indicating if we
		// want background execution or not
		args_aux[i] = NULL;
		launch_prog(args_aux, background, p_shell_priv_data);
		
		/**
		 * For the part 1.e, we only had to print the input that was not
		 * 'exit', 'pwd' or 'clear'. We did it the following way
		 */
		//	i = 0;
		//	while(args[i]!=NULL){
		//		printf("%s\n", args[i]);
		//		i++;
		//	}
	}
	return 1;
}

/* Add input command to history buffer */
int add_cmd_to_history(char *line)
{
	static int counter = 0;

	if ((line == NULL) || (strlen(line) <= 0) || (!strcmp(line, "\n")))	
		return -1;
	
	history[counter] = (char *) malloc (MAXLINE);
	memset(history[counter], 0, MAXLINE);
	memcpy(history[counter], line, strlen(line));
	
	counter++;
	
	if (counter > 50)
		counter = 0;	

	history_counter = counter;	
	return 0;	
}

/* We are exiting, hence free all runtime allocations on history */
void free_history_buffer()
{
	int i = 0;
	while (history[i] != NULL)
	{
		free(history[i]);
		i++;
	}
}

/* display history of commands entered */
void display_history()
{
	int pos = history_counter;
	if ((pos < 50) && (history[pos + 1] != NULL))
	{
		int i = pos+1;
		while (i < 50) {
			printf("%d: %s\n", i, history[i]);	
			i++; 
		} 
		if (i == 50) {
			i = 0;
			while (i < history_counter) { 
				printf("%d: %s\n", i, history[i]);	
				i++; 
			}
		}
	} else {
		int i = 0;
		while (i < history_counter) {
			printf("%d: %s\n", i, history[i]);	
			i++;
		}	
	}

}	

int token_handler(char *cmd_str, SHELL_PRIV_DATA *p_shell_priv_data)
{
    /* Parse input */
    char *token[MAX_NUM_ARGUMENTS];
    int   token_count = 0;                                 
    
    // Pointer to point to the token
    // parsed by strsep
    char *arg_ptr;                                         
    char *working_str  = strdup( cmd_str );                

    // we are going to move the working_str pointer so
    // keep track of its original value so we can deallocate
    // the correct amount at the end
    char *working_root = working_str;

    if ((token[0] = strtok(working_str, " \n\t")) == NULL)
	return -1;	
    token_count = 1;
    while ((token[token_count] = strtok(NULL, " \n\t")) != NULL)
	token_count++;
/*
    // Tokenize the input stringswith whitespace used as the delimiter
    while ( ( (arg_ptr = strsep(&working_str, WHITESPACE ) ) != NULL) && 
              (token_count<MAX_NUM_ARGUMENTS))
    {
      token[token_count] = strndup( arg_ptr, MAX_COMMAND_SIZE );
      if( strlen( token[token_count] ) == 0 )
      {
        //token[token_count] = NULL;
	continue;
      }
      token_count++;
    }
*/
    token[token_count] = NULL;

    // Now print the tokenized input as a debug check
    // TODO Remove this code and replace with your shell functionality
    int token_index  = 0;
    if(strncmp(token[token_index], "history", 7) == 0) {
		display_history();		 
    } else {
    	command_handler(token, p_shell_priv_data);
    }
    free( working_root );
}

int input_handler(char *cmd_str, SHELL_PRIV_DATA *p_shell_priv_data)
{
	char *input_str = strdup(cmd_str);
	char *temp = input_str;
	char *cmd_array[256] = {0};
        int   token_count = 0, token_index = 0;                                 
	char *arg_ptr = NULL;

        while ((arg_ptr = strsep(&temp, ";")) != NULL)
	{
		cmd_array[token_count] = strndup(arg_ptr, MAX_COMMAND_SIZE);
		if (strlen(cmd_array[token_count]) == 0)
			continue;
		token_count++;	
	}	

	for (token_index = 0; token_index < token_count; token_index++)
	{
		//printf("%s\n", cmd_array[token_index]);
		token_handler(cmd_array[token_index], p_shell_priv_data);
		printf("\n");
	}
	free(temp);		
	 
}

/**
* Main method of our shell
*/ 
int main(int argc, char *argv[], char ** envp) 
{
	char line[MAXLINE]; 	// buffer for the user input
	char *tokens[LIMIT]; 	// array for the different tokens in the command
	int  numTokens;
	SHELL_PRIV_DATA shell_priv_data;
		
	shell_priv_data.environ = NULL;
	cmd_pid = -10; // we initialize cmd_pid to an cmd_pid that is not possible
	no_reprint_prmpt = 0; 	// to prevent the printing of the shell

	// We call the method of initialization and the welcome screen
	init_shell(&shell_priv_data);
    
        // We set our extern char** environ to the environment, so that
        // we can treat it later in other methods
	shell_priv_data.environ = envp;
	
	// We set shell=<pathname>/simple-c-shell as an environment variable for
	// the child
	setenv("shell", getcwd(shell_priv_data.current_directory, 1024), 1);
	setenv("PATH", "/bin:/usr/bin:/usr/local/bin", 1);

	memset(shell_prompt, 0, 15);
	memcpy(shell_prompt, "SillyShell", strlen("SillyShell"));	

	// Main loop, where the user input will be read and the prompt
	// will be printed
	while(TRUE)
	{
		// We print the shell prompt if necessary
		if (no_reprint_prmpt == 0) 
			printf ("%s> ", shell_prompt);
		
		no_reprint_prmpt = 0;
		
		// We empty the line buffer
		memset (line, '\0', MAXLINE);

		// We wait for user input
		fgets(line, MAXLINE, stdin);

		// add this command to history
		add_cmd_to_history(line);	

		// if history requested
		if (memcmp(line, "history\n", strlen("history\n")) == 0)
		{
			display_history(history);
			continue;
		}
		if ((memcmp(line, "exit\n", strlen("exit\n")) == 0) ||
		    (memcmp(line, "quit\n", strlen("quit\n")) == 0) ||
		    (memcmp(line, "done\n", strlen("done\n")) == 0))
			break;	

		//command_handler(tokens, &shell_priv_data);
		input_handler(line, &shell_priv_data);
	}         

	// free all dynamic allocations made so far
	free(shell_priv_data.current_directory);	
	free_history_buffer(history); 
	exit(0);
}
