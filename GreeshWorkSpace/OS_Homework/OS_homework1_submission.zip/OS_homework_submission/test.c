#include <stdio.h>

int main()
{
	while (1) 
	{

	}
}
