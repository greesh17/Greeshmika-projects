#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>

// Change the constant below to change the number of philosophers
// coming to lunch...

#define PHILOSOPHER_COUNT 20

// Each philosopher request 4 chopsticks
#define N 4

// Each philosopher is represented by one thread.  Each thread independenly
// runs the same "think/start eating/finish eating" program.
pthread_t philosopher[PHILOSOPHER_COUNT];

// Each chopstick gets one mutex.  If there are N philosophers, there are
// N chopsticks.  That's the whole problem.  There's not enough chopsticks
// for all of them to be eating at the same time.  If they all cooperate,
// everyone can eat.  If they don't... or don't know how.... well....
// philosophers are going to starve.

pthread_mutex_t chopstick[PHILOSOPHER_COUNT];

// Mutex to avoid conflicts when requesting random
pthread_mutex_t m_request_chopstick;

// the status of chopstics
// 1: in used
// 0: free
int chopstick_status[PHILOSOPHER_COUNT];

// Request random chosticks available
int request_chopstick()
{
  while (1)
  {
    // Generate random int
    int id = Random_Int(PHILOSOPHER_COUNT);
    // If the choptick is free, return the result
    // Else Retry
    if (!chopstick_status[id])
    {
      return id;
    }
  }
  return -1;
}

int Random_Int(int max)
{
  return ((rand() % (max + 1)));
}

void *philosopher_program(int philosopher_number)
{ // In this version of the "philosopher program", the philosopher
  // will think and eat forever.

  int requested_chopsticks[N]; // requested chopsticks
  int i = 0;

  while (1)
  { // Philosophers always think before they eat.  They need to
    // build up a bit of hunger....

    usleep(1);

    // That was a lot of thinking.... now hungry... this
    // philosopher is a jerk.  He may not grap the chopsticks
    // closest to him.  In fact, he may grab any two chopsticks at
    // the table.... because he is a jerk.

    // Lock request chopstick available
    pthread_mutex_lock(&m_request_chopstick);
    for (i = 0; i < N; i++)
    {
      requested_chopsticks[i] = request_chopstick(); // request a chopstick
      chopstick_status[requested_chopsticks[i]] = 1; // Mark chopstick is used
    }
    // Unlock request chopstick available
    pthread_mutex_unlock(&m_request_chopstick);

    for (i = 0; i < N; i++)
    {
      pthread_mutex_lock(&chopstick[requested_chopsticks[i]]);
    }

    // Hurray, if I got this far I'm eating
    printf("\nJerk Philosopher %d is eating with chopsticks ", philosopher_number);
    for (i = 0; i < N; i++)
    {
      printf("%d ", requested_chopsticks[i]);
    }
    printf("\n");

    // I'm done eating.  Now put the chopsticks back on the table
    for (i = 0; i < N; i++)
    {
      pthread_mutex_unlock(&chopstick[requested_chopsticks[i]]);
    }
    for (i = 0; i < N; i++)
    {
      chopstick_status[requested_chopsticks[i]] = 0; // Mark chopstick is available
    }
  }

  return (NULL);
}

int main()
{
  int i;

  srand(time(NULL));
  for (i = 0; i < PHILOSOPHER_COUNT; i++)
    chopstick_status[i] = 0;
  pthread_mutex_init(&m_request_chopstick, NULL);
  for (i = 0; i < PHILOSOPHER_COUNT; i++)
    pthread_mutex_init(&chopstick[i], NULL);

  for (i = 0; i < PHILOSOPHER_COUNT; i++)
    pthread_create(&philosopher[i], NULL, (void *)philosopher_program, (void *)i);

  for (i = 0; i < PHILOSOPHER_COUNT; i++)
    pthread_join(philosopher[i], NULL);

  for (i = 0; i < PHILOSOPHER_COUNT; i++)
    pthread_mutex_destroy(&chopstick[i]);

  return 0;
}
